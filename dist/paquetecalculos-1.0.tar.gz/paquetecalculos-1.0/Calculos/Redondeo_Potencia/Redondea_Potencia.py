def  Potencia(base,exponente):
	print("El resultado de la suma es: ", base**exponente)

def  Redondear(numero):
	print("El resultado es: ", round(numero))