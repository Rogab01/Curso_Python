from setuptools import setup

setup(
	name="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Rodrigo",
	author_email="rogba1@hotmail.com",
	url="delfos.co",
	packages=["Calculos","Calculos.Redondeo_Potencia"]

	)